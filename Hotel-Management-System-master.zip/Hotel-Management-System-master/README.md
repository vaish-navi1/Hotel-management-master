# Hotel-Management-System
This Project is developed using Tkinter(python) for GUI, Mysql for Database connectivity, SMTP for mail transfer.

Options : 
check inn- takes the entry of the customers checking in via a form and stores it in the database.
customer details- used to display all the customer details
room details-  specifies the details of the customers who have checked in along with the room specifications
check out- used to check out the customers leaving the hotel along with their bill and updation in the database

Menu Bar :
1)help button in the menu bar contains the contact details has made use of SMTP to send regualr updates and offers to its customers.
2) all customers- displays details of all the customers who have checked inn
3) vacancy-  separately divides the occupied and unoccupied rooms with regular updations.

Developed by : 
1) Mishika Shukla - @pyShika
2) Rahul kumar Mishra - @TheCyberAtom
